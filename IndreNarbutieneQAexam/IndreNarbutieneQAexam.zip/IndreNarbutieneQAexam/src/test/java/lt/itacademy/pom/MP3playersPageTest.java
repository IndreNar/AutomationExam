package lt.itacademy.pom;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;

public class MP3playersPageTest extends BaseTest {

    NavbarPage navbarPage;
    MP3playersPage mp3playersPage;


//    @ParameterizedTest
//    @CsvFileSource(resources = "/searchedItems.txt")
//    public void addMP3playerToShoppingCart(String searchedItem){

        @Test
        public void addMP3playerToShoppingCart(){
        navbarPage = new NavbarPage(driver);
        mp3playersPage = new MP3playersPage(driver);

        navbarPage.clickMP3players();
        navbarPage.clickToShowAllMP3players();
        mp3playersPage.clickItemsAsLIstButton();

        String searchedItem = "iPod Classic";


        ArrayList<String> listedItems = new ArrayList<>();
        listedItems.add(mp3playersPage.get1ItemName());
        listedItems.add(mp3playersPage.get2ItemName());
        listedItems.add(mp3playersPage.get3ItemName());
        listedItems.add(mp3playersPage.get4ItemName());

//        for (int i = 0; i < listedItems.size(); i++) {
//            if(listedItems.contains(searchedItem)){
//                Assertions.assertTrue(listedItems.contains(searchedItem));
//                mp3playersPage.click1ListedItem();
//            }
//            else {
//                Assertions.assertFalse(listedItems.contains(searchedItem));
//                System.out.println(searchedItem + " does not exist in the eshop");
//            }

            Assertions.assertTrue(listedItems.contains(searchedItem), searchedItem + " does not exist in the eshop");
            mp3playersPage.click1ListedItem();
            mp3playersPage.clickWishListButton();

            String expectedMessageWishList = "You must login or create an account to save " + searchedItem + " to your wish list!\n×";

            new WebDriverWait(driver, Duration.ofSeconds(2))
                    .until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@id='button-cart']")));
            String displayedMessage = mp3playersPage.getAlertMessage();
            Assertions.assertEquals(expectedMessageWishList, displayedMessage, "Messages do not match");

            driver.navigate().refresh();

            new WebDriverWait(driver, Duration.ofSeconds(2))
                    .until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@id='button-cart']")));

            mp3playersPage.clickAddToCartButton();

            String expectedMessageAddToCart = "You have added " + searchedItem + " to your shopping cart!";

            new WebDriverWait(driver, Duration.ofSeconds(2))
                    .until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.alert.alert-success.alert-dismissible")));
            String displayedMessageAddToCart = mp3playersPage.getAlertMessage();

            Assertions.assertTrue(displayedMessageAddToCart.contains(expectedMessageAddToCart), "Messages do not match after adding " + searchedItem + " to shopping cart");


            Assertions.assertTrue(mp3playersPage.getTextInShoppingCart().contains("1 item"), "Item was not added into the shopping cart");

        }









    }

