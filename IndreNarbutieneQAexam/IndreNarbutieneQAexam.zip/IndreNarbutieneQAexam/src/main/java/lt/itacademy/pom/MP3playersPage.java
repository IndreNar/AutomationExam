package lt.itacademy.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class MP3playersPage extends AbstractPage {

    @FindBy(css = "button[id='list-view']")
    private WebElement itemsAsListButton;

    @FindBy(css = ".product-layout")
    private List<WebElement> listedItem;

    @FindBy(css = "div:first-child > div > div:nth-child(2) > div.caption > h4 > a")
    private WebElement firstListedItem;

    @FindBy(css = "div:nth-child(2) > div > div:nth-child(2) > div.caption > h4 > a")
    private WebElement secondListedItem;

    @FindBy(css = "div:nth-child(3) > div > div:nth-child(2) > div.caption > h4 > a")
    private WebElement thirdListedItem;

    @FindBy(css = "div:nth-child(4) > div > div:nth-child(2) > div.caption > h4 > a")
    private WebElement fourthListedItem;

    @FindBy(css = "#content > div > div.col-sm-4 > div.btn-group > button:nth-child(1)")
    private WebElement wishListButton;

    @FindBy(css = "div.alert.alert-success.alert-dismissible")
    private WebElement alertMessage;

    @FindBy(xpath = "//button[@id='button-cart']")
    private WebElement addToCartButton;

    @FindBy(css = "div[id='cart'] > button")
    private WebElement shoppingCart;


    public MP3playersPage(WebDriver driver) {
        super(driver);
    }

    public void clickItemsAsLIstButton(){
        itemsAsListButton.click();
    }

    public List<WebElement> listedItems(){
        return listedItem;
    }



    public String get1ItemName(){
        return firstListedItem.getText();
    }

    public String get2ItemName(){
        return secondListedItem.getText();
    }

    public String get3ItemName(){
        return thirdListedItem.getText();
    }

    public String get4ItemName(){
        return fourthListedItem.getText();
    }

    public void click1ListedItem(){
        firstListedItem.click();
    }

    public void click2ListedItem(){
        secondListedItem.click();
    }

    public void click3ListedItem(){
        thirdListedItem.click();
    }

    public void click4ListedItem(){
        fourthListedItem.click();
    }

    public void clickWishListButton(){
        wishListButton.click();
    }

    public String getAlertMessage(){
        return alertMessage.getText();
    }

    public void clickAddToCartButton(){
        addToCartButton.click();
    }

    public String getTextInShoppingCart(){
        return shoppingCart.getText();
    }
}
